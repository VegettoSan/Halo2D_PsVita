#include <stdio.h>
#include <kernel.h>
#include <moduleinfo.h>
#include <libsysmodule.h>

#define PRX_EXPORT extern "C" __declspec (dllexport)

SCE_MODULE_INFO( NativePluginExample, SCE_MODULE_ATTR_NONE, 1, 1);

extern "C" int module_start(SceSize sz, const void* arg)
{
	return SCE_KERNEL_START_SUCCESS;
}

PRX_EXPORT int GetInteger()
{
	return 6;
}

PRX_EXPORT const char* GetString()
{
	return "Hello";
}

PRX_EXPORT int AddTwoIntegers(int i1, int i2)
{
	return i1 + i2;
}

PRX_EXPORT float AddTwoFloats(float f1, float f2)
{
	return f1 + f2;
}

struct ReturnedStructure
{
	int number;
	const char* text;
};

PRX_EXPORT bool ReturnAStructure(ReturnedStructure* data)
{
	static char sText[] = "Hello";
	data->number = 23;
	data->text = sText;
}
